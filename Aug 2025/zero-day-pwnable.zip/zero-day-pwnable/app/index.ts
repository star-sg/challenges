import Koa from 'koa';
import Router from '@koa/router';
import bodyParser from '@koa/bodyparser';
import { promises as fs } from 'fs';
import { randomBytes } from 'crypto';
import { ISVMParam, SVM, SVMParam } from './libsvm-wasm/src';

const app = new Koa();
const router = new Router();
const port = 3000;

app.use(bodyParser());

function validateTrainingPayload(body: any): string | null {
  const { data, labels, params } = body;

  if (!data || !labels || !params) return 'Missing data, labels, or params.';
  if (!Array.isArray(labels) || !labels.every(item => typeof item === 'number')) return 'Invalid format: labels must be an array of numbers.';
  if (!Array.isArray(data) || data.length === 0) return 'Invalid format: data must be a non-empty array of arrays.';
  for (const row of data) {
    if (!Array.isArray(row) || !row.every(item => typeof item === 'number')) return 'Invalid format: each item in data must be an array of numbers.';
  }
  if (data.length !== labels.length) return 'Inconsistent data: number of samples must match number of labels.';

  if (typeof params !== 'object' || params === null) {
      return 'Invalid format: params must be an object.';
  }
  const numberParams = new Set(['svm_type', 'kernel_type', 'degree', 'gamma', 'coef0', 'cache_size', 'C', 'nr_weight', 'nu', 'p', 'shrinking', 'probability']);
  const arrayParams = new Set(['weight_label', 'weight']);

  for (const key in params) {
    const value = params[key];
    if (!numberParams.has(key) && !arrayParams.has(key)) {
      return `Invalid param: '${key}' is not a recognized SVM parameter.`;
    }
    if (numberParams.has(key) && typeof value !== 'number') {
      return `Type error: parameter '${key}' must be a number.`;
    }
    if (arrayParams.has(key) && (!Array.isArray(value) || !value.every(item => typeof item === 'number'))) {
      return `Type error: parameter '${key}' must be an array of numbers.`;
    }
  }

  return null;
}

router.post('/api/train', async (ctx) => {
  const validationError = validateTrainingPayload(ctx.request.body);
  if (validationError) {
    ctx.status = 400; // Bad Request
    ctx.body = { error: validationError };
    return;
  }

  const { data, labels, params } = ctx.request.body as { data: number[][]; labels: number[]; params: ISVMParam };

  const svm = new SVM(new SVMParam(params));
  await svm.init()
  svm.feedSamples(data, labels);
  await svm.train();

  const outputFilename = `${randomBytes(16).toString('hex')}.svm`;
  svm.save(outputFilename)
  const fileBuffer = await fs.readFile(outputFilename);
  await fs.rm(outputFilename);
  ctx.set('Content-Type', 'application/octet-stream');
  ctx.set('Content-Disposition', `attachment; filename="${outputFilename}"`);
  ctx.body = fileBuffer;
});

app.use(router.routes()).use(router.allowedMethods());

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});