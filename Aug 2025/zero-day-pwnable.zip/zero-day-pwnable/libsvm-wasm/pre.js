var Module = {
  preRun: [function() {
    ENV.FLAG = process.env.FLAG || 'default_flag';
  }]
};